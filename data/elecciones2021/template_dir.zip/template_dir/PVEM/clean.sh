#!/bin/bash
#
rm twarc.log
rm output.log
rm command.txt
rm queryStringFile.txt
rm test.jsonl
