#!/bin/bash
#
rm twarc.log
rm output.log
rm command.txt
rm test.jsonl
